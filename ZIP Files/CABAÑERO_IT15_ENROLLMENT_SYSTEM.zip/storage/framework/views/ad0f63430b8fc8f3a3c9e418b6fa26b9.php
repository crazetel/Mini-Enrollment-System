<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>PinkPortal | Access</title>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    </head>
    <body class="font-sans text-gray-900 antialiased bg-pink-50">
        <div class="min-h-screen flex flex-col sm:justify-center items-center pt-6 sm:pt-0 bg-gradient-to-br from-pink-100 to-rose-200">
            <div class="mb-8">
                <a href="/" class="text-3xl font-black text-pink-600 tracking-tighter hover:opacity-80 transition">
                    PINK<span class="text-gray-800">PORTAL</span>
                </a>
            </div>

            <div class="w-full sm:max-w-md px-10 py-12 bg-white/90 backdrop-blur-xl shadow-[0_20px_50px_rgba(255,182,193,0.3)] overflow-hidden sm:rounded-[3rem] border border-white">
                <?php echo e($slot); ?>

            </div>

            <p class="mt-8 text-xs text-pink-400 font-bold tracking-widest uppercase">&copy; 2026 PinkPortal System</p>
        </div>
    </body>
</html><?php /**PATH C:\Dev\Projects\Laravel\mini-enrollment-system\resources\views/layouts/guest.blade.php ENDPATH**/ ?>