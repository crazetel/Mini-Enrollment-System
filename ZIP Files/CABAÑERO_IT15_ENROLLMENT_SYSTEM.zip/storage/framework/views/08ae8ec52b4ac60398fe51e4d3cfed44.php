
<?php $__env->startSection('content'); ?>
<div class="mb-12">
    <p class="text-cyan-400 font-black text-[10px] uppercase tracking-[0.5em] mb-2">Security & Identity</p>
    <h1 class="text-6xl font-serif italic tracking-tighter text-white">Manage <span class="opacity-40 text-white">Users</span></h1>
</div>

<div class="glass rounded-[3rem] overflow-hidden shadow-2xl">
    <table class="w-full text-left border-collapse">
        <thead class="bg-white/5 border-b border-white/10">
            <tr class="text-[10px] font-black uppercase tracking-widest text-white/40">
                <th class="px-10 py-6">User Identity</th>
                <th class="px-10 py-6">Current Role</th>
                <th class="px-10 py-6 text-right">Actions</th>
            </tr>
        </thead>
        <tbody class="divide-y divide-white/5">
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="hover:bg-white/5 transition group">
                <td class="px-10 py-8">
                    <div class="font-bold text-lg group-hover:text-pink-400 transition"><?php echo e($user->name); ?></div>
                    <div class="text-xs opacity-40 uppercase tracking-widest"><?php echo e($user->email); ?></div>
                </td>
                <td class="px-10 py-8">
                    <span class="px-4 py-1 rounded-full text-[9px] font-black uppercase tracking-widest <?php echo e($user->role == 'admin' ? 'bg-pink-500/20 text-pink-400' : 'bg-cyan-500/20 text-cyan-400'); ?>">
                        <?php echo e($user->role); ?>

                    </span>
                </td>
                <td class="px-10 py-8 text-right">
                    <form action="<?php echo e(route('admin.users.update', $user)); ?>" method="POST">
                        <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                        <select name="role" onchange="this.form.submit()" class="bg-transparent border-none text-[10px] font-black uppercase tracking-widest cursor-pointer focus:ring-0">
                            <option value="student" <?php echo e($user->role == 'student' ? 'selected' : ''); ?>>Make Student</option>
                            <option value="admin" <?php echo e($user->role == 'admin' ? 'selected' : ''); ?>>Make Admin</option>
                        </select>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Dev\Projects\Laravel\mini-enrollment-system\resources\views/admin/users.blade.php ENDPATH**/ ?>